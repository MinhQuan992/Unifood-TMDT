
CREATE VIEW view_GioHang
AS
    SELECT g.MaGio, g.MaNguoiDung, d.MaSanPham, d.SoLuong
    FROM GIOHANG AS g INNER JOIN DATHANG AS d ON g.MaGio = d.MaGio
    WHERE g.MaGio NOT IN (SELECT MaGio FROM DONHANG)
go

