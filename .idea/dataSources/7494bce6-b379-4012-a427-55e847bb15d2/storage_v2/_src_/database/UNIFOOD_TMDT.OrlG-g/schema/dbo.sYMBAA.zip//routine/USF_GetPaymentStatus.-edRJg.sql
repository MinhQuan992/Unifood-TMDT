
create function USF_GetPaymentStatus(@status bit)
returns nvarchar(50) 
as 
begin
	if  (@status=1)
		return N'Đã thanh toán'
	return N'Chưa thanh toán' 
end
go

