
create view [ViewAllOrder] as
select DH.MaDon as MaDon, dbo.USF_GetUserNameOfCart(DH.MaGio) as TenNguoiDung, 
		DH.DiaChi, DH.MaNguoiVanChuyen,
		DH.NgayDat as NgayDat, DH.NgayGiaoHang as NgayGiaoHang, DH.NgayThanhToan as NgayThanhToan, 
		DH.TongGiaTri as TongGiaTri, DH.TT_DonHang as TrangThaiDonHang, dbo.USF_GetPaymentStatus(DH.TT_ThanhToan) as TrangThaiThanhToan
from DONHANG DH
go

