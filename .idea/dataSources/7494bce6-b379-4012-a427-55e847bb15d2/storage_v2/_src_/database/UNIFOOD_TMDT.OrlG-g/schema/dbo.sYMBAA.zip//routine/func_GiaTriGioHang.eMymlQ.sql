
CREATE FUNCTION func_GiaTriGioHang(@maGio INT)
RETURNS INT
AS
BEGIN
	DECLARE @result INT
	SELECT @result = SUM(SP.DonGia * DH.SoLuong)
	FROM DATHANG DH INNER JOIN SANPHAM SP ON DH.MaSanPham = SP.MaSanPham
	WHERE MaGio = @maGio
	RETURN @result
END
go

