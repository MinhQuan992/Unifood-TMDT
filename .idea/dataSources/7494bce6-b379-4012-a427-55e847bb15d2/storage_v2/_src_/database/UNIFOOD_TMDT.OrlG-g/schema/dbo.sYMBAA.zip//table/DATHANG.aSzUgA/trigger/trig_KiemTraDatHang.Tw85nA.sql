
-- TẠO TRIGGER KIỂM TRA BẢNG ĐẶT HÀNG --
CREATE TRIGGER trig_KiemTraDatHang
ON DATHANG
AFTER INSERT, UPDATE
AS
BEGIN
	DECLARE @maGio INT
	SELECT @maGio = MaGio
	FROM inserted

	IF @maGio IN (SELECT MaGio FROM DONHANG)
	BEGIN
		RAISERROR('Giỏ hàng đã được xác nhận, bạn không thể thay đổi', 16, 1)
		ROLLBACK TRAN
	END
	ELSE
	BEGIN
		DECLARE @maSanPham VARCHAR(10)
		SELECT @maSanPham = MaSanPham
		FROM inserted

		DECLARE @donGia INT
		SELECT @donGia = DonGia
		FROM SANPHAM
		WHERE MaSanPham = @maSanPham

		UPDATE DATHANG SET DonGia = @donGia WHERE MaGio = @maGio AND MaSanPham = @maSanPham
	END
END
go

