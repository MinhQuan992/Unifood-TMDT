
create function USF_GetItemQuantity(@itemCode char(10))
returns int 
as
begin
	declare @num int
	select @num = Pr.SoLuong
	from dbo.SANPHAM Pr
	where Pr.MaSanPham = @itemCode
	if (@num>0) return @num
	return 0
end
go

