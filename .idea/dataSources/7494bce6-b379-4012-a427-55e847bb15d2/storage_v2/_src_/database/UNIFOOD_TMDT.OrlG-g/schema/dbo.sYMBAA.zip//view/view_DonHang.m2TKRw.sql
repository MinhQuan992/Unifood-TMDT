CREATE VIEW view_DonHang AS
SELECT MaDon, MaNguoiDung, MaNguoiVanChuyen, DiaChi, TT_DonHang, TT_ThanhToan, TongGiaTri, NgayDat, NgayGiaoHang, NgayThanhToan
FROM GIOHANG INNER JOIN DONHANG ON GIOHANG.MaGio = DONHANG.MaGio
go

